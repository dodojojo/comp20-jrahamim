// Express initialization
var express = require('express');
var app = express(express.logger());
app.use(express.bodyParser());
app.set('title', 'nodeapp');

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://localhost/scorecenter';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});

//Enable cross origin sharing on all routes
app.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.get('/', function (request, response) {
	
	response.set("Content-Type", "text/html")
	var scores = db.collection('scores');
    
    scores.find().toArray(function(err, docs) { 
    	  results = "";
    	  for(var j=0; j < docs.length; j++)
    	  {      
          	results += "<div>"+ docs[j].username + "      " + docs[j].game_title + "      "
          						 + docs[j].score + "      " + docs[j].created_at +  "</div>";
          }
          response.send(results);
    	});          
});

app.post('/submit.json', function(request, response) {
			sent_game_info = request.body;

	   		d = new Date();
			date = d.getDate() + "/" +( d.getMonth() + 1) + "/" + d.getFullYear() + " " + d.getHours() + ":" + d.getMinutes(); 
			sent_game_info["created_at"] = date;
			
			var scores = db.collection('scores');
			scores.insert(sent_game_info);
			
			response.set('Content-Type', 'text/json');
			response.send('{"status":"good"}');		
	
});


app.get('/highscores.json', function(request, response) {
	response.set('Content-Type', 'text/json');
	var game_name = request.query.game_title;
	highscores_json = [];
	
	var scores = db.collection('scores');
	scores.find({"game_title":game_name}).toArray(function(err, docs) {
    	highscores_json = docs;
    	highscores_json.sort(function(a,b){return parseFloat(b.score) - parseFloat(a.score)});
    	while(highscores_json.length > 10){
    		highscores_json.pop();
    	}
    	response.send(highscores_json);
    });
});

app.get('/usersearch', function(request, response) {
	var name = request.query.username;
	if(name == undefined){
		response.sendfile('public/html/usersearch.html');
		}
	else{
		var scores = db.collection('scores');
		highscores = "";
		scores.find({"username":name}).toArray(function(err, docs) {
			if(docs.length == 0){response.send("<h3>No Results Found</h3>");}
   			for( j in docs){
   				highscores += "<div>"+ docs[j].username + "      " + docs[j].game_title + "      "
   				 + docs[j].score + "      " + docs[j].created_at +  "</div>";
   			}
   		response.send(highscores);
      });	
	}
});

app.listen(process.env.PORT || 3000);